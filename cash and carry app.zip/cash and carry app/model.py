import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor

# Load and preprocess dataset
@st.cache_data
def load_data():
    file_path = "Data for Cash and Carry.csv"
    df = pd.read_csv(file_path)

    # Convert Date to datetime format
    df['Date'] = pd.to_datetime(df['Date'], format="%m/%d/%Y")

    # Convert currency columns to numeric
    currency_columns = ['Sales (PKR)']
    for col in currency_columns:
        df[col] = df[col].str.replace(',', '', regex=True).astype(float)

    return df

df = load_data()

# Encode 'Category' column
label_enc = LabelEncoder()
df['Category'] = label_enc.fit_transform(df['Category'])

# Prepare training data (only Date & Category)
X = df[['Date', 'Category']].copy()
X['Date'] = X['Date'].apply(lambda x: x.toordinal())  # Convert date to numerical format
y = df['Sales (PKR)']

# Train the model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Streamlit UI
st.title("Sales Prediction App (Based on Date & Category)")

# User inputs
date_input = st.date_input("Select Date:")
category_input = st.selectbox("Select Category:", label_enc.classes_)

# Convert inputs for prediction
category_encoded = label_enc.transform([category_input])[0]
date_encoded = datetime.toordinal(pd.to_datetime(date_input))

# Make prediction
if st.button("Predict Sales"):
    input_data = np.array([[date_encoded, category_encoded]])
    prediction = model.predict(input_data)
    
    st.success(f"Predicted Sales for {category_input} on {date_input}: PKR {prediction[0]:,.2f}")
